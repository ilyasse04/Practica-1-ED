#include <iostream>
#include "GestorClientes.h"
#include "comun.h"

using namespace std;

int main()
{
    cadena Dni;
    int pos;
    TCliente cliente;
    GestorClientes gestor ("ClientesSin.dat");

    /*int opc, opc1, opc2, opc3;

    do {
    cout << "-----Menu Principal-----" << endl;
    cout << "1.- Gestion de Clientes." << endl;
    cout << "2.- Gestion de Vehiculos." << endl;
    cout << "3.- Gestion de Alquileres." << endl;
    cout << "0- Salir" << endl;
    cout << "Introduzca opcion: " << endl;
    cin >> opc;

    switch (opc) {
        case 1:
            do {
            cout << "-----Menu Gestion de Clientes-----" << endl;
            cout << "1.- Consulta de clientes" << endl;
            cout << "2.- Buscar un nuevo cliente" << endl;
            cout << "3.- Nuevo cliente" << endl;
            cout << "4.- Modificar cliente" << endl;
            cout << "5.- Eliminar un cliente" << endl;
            cout << "0.- Salir" << endl;
            cout << "Introduzca una opcion: " << endl;
            cin >> opc1;

            switch (opc1) {

            case 1:
                break;

            case 2:
                break;

            case 3:
                break;

            case 4:
                break;

            case 5:
                break;

            case 6:
                break;
            }
            }
            while (opc1 != 0);
            break;

        case 2:
            do {
            cout << "-----Menu Gestion de Vehiculos-----" << endl;
            cout << "1.- Consulta de Vehiculos" << endl;
            cout << "2.- Buscar un vehiculo" << endl;
            cout << "3.- Nuevo vehiculo" << endl;
            cout << "4.- Modificar vehiculo" << endl;
            cout << "5.- Eliminar un vehiculo" << endl;
            cout << "0.- Salir" << endl;
            cout << "Introduzca una opcion: " << endl;
            cin >> opc2;

            switch (opc2) {

            case 1:
                break;

            case 2:
                break;

            case 3:
                break;

            case 4:
                break;

            case 5:
                break;

            case 6:
                break;
            }
            }
            while (opc2 != 0);
            break;

        case 3:
            do {
            cout << "-----Menu Gestion de Alquileres-----" << endl;
            cout << "1.- Mostrar Vehiculos alquilados" << endl;
            cout << "2.- Alquilar un vehiculo" << endl;
            cout << "3.- Devolver un vehiculo" << endl;
            cout << "0.- Salir" << endl;
            cout << "Introduzca una opcion: " << endl;
            cin >> opc3;

            switch (opc3) {

            case 1:
                break;

            case 2:
                break;

            case 3:
                break;
            }
            }
            while (opc3 != 0);
            break;

        case 4: cout << "Saliendo del programa..." << endl;
            break;
    }
    }

    while (opc != 0);*/

    //98680645X
    //98002599V





    return 0;
}
