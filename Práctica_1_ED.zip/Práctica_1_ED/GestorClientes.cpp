#include "GestorClientes.h"
#include <iostream>
#include <fstream>
#include <cstring>

 GestorClientes::GestorClientes(cadena NomFile) {

     int nClientes;

     fichero.open("ClientesSin.dat", ios::binary | ios::in | ios::out);

     if (fichero.fail())
        cout << "Error al abrir el fichero..." << endl;

     else {

        fichero.read((char *) &nClientes, sizeof(int));

     }

     numClientes = nClientes;

}

GestorClientes::~GestorClientes() {

    fichero.close();

}

 int GestorClientes::getNumClientes() {

     return numClientes;

 }

bool GestorClientes::mostrar(cadena Dni) {

    bool mostrado = false;
    TCliente cliente;

    if (strcmp(Dni, "*") == 0) {

    cout << "DNI\t\t Nombre\t\t\t\t Provincia\t Km Acumulados\t\t Euros Acumulados\t V en Alquiler" << endl;
    cout << "**************************************************************************************************************************************" << endl;

    for (int i = 0; i < numClientes; i++) {

            fichero.read((char *) &cliente, sizeof(TCliente));

            cout << cliente.Dni << "\t"
            << cliente.Nombre << "\t\t"
            << cliente.Provincia << "\t\t"
            << cliente.AcumuKm << "\t\t"
            << cliente.AcumuEuros << "\t\t"
            << cliente.VEnAlquiler << endl;
            cout << endl;

           mostrado = true;

        }
    }

    else {

        fichero.seekg(sizeof(int), ios::beg);

        for (int i = 0; i < numClientes; i++) {

                fichero.read((char *) &cliente, sizeof(TCliente));

                if (strcmp(cliente.Dni, Dni) == 0) {

                    cout << cliente.Dni << "\t"
                    << cliente.Nombre << "\t\t"
                    << cliente.Provincia << "\t\t"
                    << cliente.AcumuKm << "\t\t"
                    << cliente.AcumuEuros << "\t\t"
                    << cliente.VEnAlquiler << endl;
                    cout << endl;

                    mostrado = true;

                    }
        }

        if (mostrado == false)
            cout << "No hay ningun cliente con el DNI proporcionado..." << endl;

    }

    return mostrado;

}

int GestorClientes::buscar(cadena Dni) {

    TCliente cliente;
    bool encontrado = false;
    int posicion = -1;

    fichero.seekg(sizeof(int), ios::beg);

    for (int i = 0; i < numClientes; i++) {

            fichero.read((char *) &cliente, sizeof(TCliente));

            if(strcmp(cliente.Dni, Dni) == 0) {

            posicion = fichero.tellg();
            encontrado = true;

        }
    }

    if (encontrado) {

        return posicion;

    }

    else {

        cout << "No hay ningun cliente con ese DNI..." << endl;
        return -1;

    }
}

TCliente GestorClientes::consultar(int Posicion) {

    TCliente cliente;

    if (Posicion > 0 && Posicion < numClientes) {

    fichero.seekg(sizeof(int) + sizeof(TCliente) * Posicion, ios::beg);
    fichero.read((char *) &cliente, sizeof(TCliente));
    //hacer cout en main

    }

    else {

        cout << "Dni: *" << endl;
        cout << "Nombre: *" << endl;
        cout << "Provincia: *" << endl;
        cout << "Kilometros acumulados: *" << endl;
        cout << "Euros acumulados: *" << endl;
        cout << "Vehiculo en alquiler: " << endl;

    }

    return cliente;
}

void GestorClientes::insertar(TCliente C) {

}

bool GestorClientes::modificar(TCliente C, int Posicion) {

    bool correcta = false;
    cadena Dni, nombre, provincia, alquiler;
    int km, euros;

    if (Posicion < 0 || Posicion > numClientes) {

        cout << "Posicion incorrecta..." << endl;
        correcta = false;
    }

    else {

            fichero.seekp(sizeof(int) + sizeof(TCliente) * Posicion, ios::beg);
            fichero.write((char *) &C, sizeof(TCliente));

            cout << "Introduzca el nuevo Dni: " << endl;
            cin >> Dni;
            strcpy(C.Dni, Dni);
            cout << "Introduzca el nuevo nombre: " << endl;
            gets(nombre);
            strcpy(C.Nombre, nombre);
            cout << "Inrtroduzca la nueva provincia: " << endl;
            cin >> provincia;
            strcpy(C.Provincia, provincia);
            cout << "Introduzca los kilometros acumulados: " << endl;
            cin >> km;
            C.AcumuKm = km;
            cout << "Introduzca los euros acumulados: " << endl;
            cin >> euros;
            C.AcumuEuros = euros;
            cout << "Esta en alquiler? (Si o no): " << endl;
            cin >> alquiler;
            //duda
            correcta = true;
    }

    return correcta;

}

bool GestorClientes::eliminar(int Posicion) {

    bool correcta = false;
    TCliente C;
    if (Posicion < 0 || Posicion > numClientes) {

        cout << "Posicion incorrecta..." << endl;
        correcta = false;

    }

    else {

            fichero.seekp(sizeof(int) + sizeof(TCliente) * Posicion, ios::beg);

            for (int i = Posicion; i < numClientes; i++) {

                    C = consultar(i+1);
                    modificar(C, i);
                    correcta = true;

            }

            numClientes--;
    }


}


