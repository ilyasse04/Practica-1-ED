#include "GestorVehiculos.h"
#include "Comun.h"
#include <fstream>
//constructor, reservar memoria para cada vehiculo en el puntero vehiculos (incremento), con el new, y comprobar que se ha reservado. Despues abrir fichero y comprobar si se ha abierto, esquema de recorrido, en cada iteracion, preguntar si hay espacio en el vector dinamico para almacenar el registro y cuando no haya espacio, redimensionar el vector(comprobar con cada redimension si se ha podido crear el new), liberar espacio del puntero para apuntar al nuevo vector(redimensionado), cerrar el fichero principal al final

GestorVehiculos::GestorVehiculos(cadena nomPpal) {

    int i = 0;
    tam = INCREMENTO;

    vehiculos = new Vehiculo[tam];

    if (vehiculos == NULL) {

        cout << "No se ha podido crear memoria dinamica..." << endl;

    }

    else {

    ficheroPrincipal.open("vehiculos.bin", ios::binary | ios::in | ios::out);

    if (ficheroPrincipal.fail())
        cout << "Error al abrir el fichero..." << endl;

    else {

        while (i < numVehiculos && !ficheroPrincipal.eof()) {

        ficheroPrincipal.write((char *) &vehiculos, sizeof(Vehiculo));

        if (tam == numVehiculos) {

            aumentarArray();

        }

        i++;

        }

        ficheroPrincipal.close();
    }
    }
}

void GestorVehiculos::aumentarArray() {

        tam += INCREMENTO;
        Vehiculo *nuevovector = new Vehiculo[tam];

        for (int i = 0; i < numVehiculos; i++) {

            vehiculos[i] = nuevovector[i];

        }

        delete[] vehiculos;
        vehiculos = nuevovector;

}

GestorVehiculos::~GestorVehiculos() {

    ficheroPrincipal.open("vehiculos.bin", ios::binary | ios::in | ios::out);

    // codigo

    delete[] vehiculos;
    ficheroPrincipal.close();


}

int GestorVehiculos::getNumVehiculos() {

    return numVehiculos;

}






